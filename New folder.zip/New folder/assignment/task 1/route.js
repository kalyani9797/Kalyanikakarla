var app = angular.module('myApp', ['ngRoute']);
 
app.config(function($routeProvider) {
$routeProvider
 
.when('/', {
templateUrl : 'pages/first.html',
controller : 'FirstController'
})
 
.when('/blog', {
templateUrl : 'pages/second.html',
controller : 'SecondController'
})
 
.when('/about', {
templateUrl : 'pages/third.html',
controller : 'ThirdController'
})
 
.otherwise({redirectTo: '/'});
});
